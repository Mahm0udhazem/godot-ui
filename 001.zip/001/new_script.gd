extends Node

var previous_scene: PackedScene = null
