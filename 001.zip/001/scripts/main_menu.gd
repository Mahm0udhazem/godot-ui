extends Control

@export var game_scene: PackedScene
@export var settings_scene: PackedScene

func _on_start_pressed():
	if game_scene:
		get_tree().change_scene_to_packed(game_scene)

func _on_settings_pressed():
	NewScript.previous_scene = load("res://scenes/main_menu.tscn")
	if settings_scene:
		get_tree().change_scene_to_packed(settings_scene)

func _on_quit_pressed():
	get_tree().quit()


func _on_start_button_pressed() -> void:
	pass # Replace with function body.


func _on_settings_button_pressed() -> void:
	pass # Replace with function body.
