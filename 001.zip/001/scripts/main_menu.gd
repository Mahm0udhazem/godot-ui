@tool
extends Control

@export var game_scene_path: String = "res://Game.tscn"
@export var settings_scene_path: String = "res://SettingsMenu.tscn"

@onready var bg = $Background
@onready var container = $MenuContainer
@onready var title = $MenuContainer/TitleLabel
@onready var start_btn = $MenuContainer/StartButton
@onready var settings_btn = $MenuContainer/SettingsButton
@onready var quit_btn = $MenuContainer/QuitButton

func _ready():
	setup_layout()
	if not Engine.is_editor_hint():
		start_btn.pressed.connect(_on_start)
		settings_btn.pressed.connect(_on_settings)
		quit_btn.pressed.connect(_on_quit)

func setup_layout():
	anchor_right = 1.0
	anchor_bottom = 1.0
	
	if bg:
		bg.anchor_right = 1.0
		bg.anchor_bottom = 1.0
		bg.color = Color(0.1, 0.08, 0.14, 1.0)
	
	if container:
		container.anchor_left = 0.35
		container.anchor_top = 0.2
		container.anchor_right = 0.65
		container.anchor_bottom = 0.8
		container.alignment = BoxContainer.ALIGNMENT_CENTER
		container.add_theme_constant_override("separation", 20)
	
	if title:
		title.text = "GAME TITLE"
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		title.add_theme_font_size_override("font_size", 42)
	
	if start_btn:
		style_button(start_btn, "START GAME", Color(0.2, 0.6, 0.4, 1.0))
	if settings_btn:
		style_button(settings_btn, "SETTINGS", Color(0.25, 0.35, 0.6, 1.0))
	if quit_btn:
		style_button(quit_btn, "QUIT", Color(0.6, 0.25, 0.25, 1.0))

func style_button(btn: Button, text_val: String, base_color: Color):
	btn.text = text_val
	btn.custom_minimum_size = Vector2(0, 55)
	
	var style_normal = StyleBoxFlat.new()
	style_normal.bg_color = base_color
	style_normal.corner_radius_top_left = 8
	style_normal.corner_radius_top_right = 8
	style_normal.corner_radius_bottom_left = 8
	style_normal.corner_radius_bottom_right = 8
	
	var style_hover = style_normal.duplicate()
	style_hover.bg_color = base_color.lightened(0.2)
	
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_hover)
	btn.add_theme_stylebox_override("pressed", style_normal)
	btn.add_theme_font_size_override("font_size", 20)

func _on_start():
	get_tree().change_scene_to_file(game_scene_path)

func _on_settings():
	get_tree().change_scene_to_file(settings_scene_path)

func _on_quit():
	get_tree().quit()
