extends Control

@onready var fps_btn = $SettingsList/FPS_Option
@onready var quality_btn = $SettingsList/Quality_Option
@onready var music_slider = $SettingsList/Music_Slider
@onready var sfx_slider = $SettingsList/SFX_Slider

func _ready():
	if fps_btn:
		fps_btn.clear()
		fps_btn.add_item("Unlimited", 0)
		fps_btn.add_item("30 FPS", 30)
		fps_btn.add_item("60 FPS", 60)
		fps_btn.add_item("144 FPS", 144)

	if quality_btn:
		quality_btn.clear()
		quality_btn.add_item("Low")
		quality_btn.add_item("Medium")
		quality_btn.add_item("High")

	var music_bus = AudioServer.get_bus_index("Music")
	if music_bus != -1 and music_slider:
		music_slider.value = db_to_linear(AudioServer.get_bus_volume_db(music_bus)) * 100

	var sfx_bus = AudioServer.get_bus_index("SFX")
	if sfx_bus != -1 and sfx_slider:
		sfx_slider.value = db_to_linear(AudioServer.get_bus_volume_db(sfx_bus)) * 100

func _on_fps_option_item_selected(index):
	Engine.max_fps = fps_btn.get_item_id(index)

func _on_quality_option_item_selected(index):
	if index == 0:
		get_viewport().msaa_2d = Viewport.MSAA_DISABLED
	elif index == 1:
		get_viewport().msaa_2d = Viewport.MSAA_2X
	else:
		get_viewport().msaa_2d = Viewport.MSAA_4X

func _on_music_slider_value_changed(value):
	var bus = AudioServer.get_bus_index("Music")
	if bus != -1:
		if value <= 0:
			AudioServer.set_bus_mute(bus, true)
		else:
			AudioServer.set_bus_mute(bus, false)
			AudioServer.set_bus_volume_db(bus, linear_to_db(value / 100.0))

func _on_sfx_slider_value_changed(value):
	var bus = AudioServer.get_bus_index("SFX")
	if bus != -1:
		if value <= 0:
			AudioServer.set_bus_mute(bus, true)
		else:
			AudioServer.set_bus_mute(bus, false)
			AudioServer.set_bus_volume_db(bus, linear_to_db(value / 100.0))

func _on_back_pressed():
	if NewScript.previous_scene:
		get_tree().change_scene_to_packed(NewScript.previous_scene)
	else:
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
