@tool
extends Control

@export var main_menu_path: String = "res://MainMenu.tscn"

@onready var bg = $Background
@onready var list = $SettingsList
@onready var title = $SettingsList/TitleLabel
@onready var fps_label = $SettingsList/FPSLabel
@onready var fps_options = $SettingsList/FPS_Option
@onready var quality_label = $SettingsList/QualityLabel
@onready var quality_options = $SettingsList/Quality_Option
@onready var music_label = $SettingsList/MusicLabel
@onready var music_slider = $SettingsList/Music_Slider
@onready var sfx_label = $SettingsList/SFXLabel
@onready var sfx_slider = $SettingsList/SFX_Slider
@onready var back_btn = $SettingsList/BackButton

func _ready():
	setup_layout()
	
	if not Engine.is_editor_hint():
		fps_options.clear()
		fps_options.add_item("Unlimited", 0)
		fps_options.add_item("30 FPS", 30)
		fps_options.add_item("60 FPS", 60)
		fps_options.add_item("144 FPS", 144)
		fps_options.item_selected.connect(_on_fps_changed)

		quality_options.clear()
		quality_options.add_item("Low")
		quality_options.add_item("Medium")
		quality_options.add_item("High")
		quality_options.item_selected.connect(_on_quality_changed)

		setup_audio_sliders()
		back_btn.pressed.connect(_on_back)

func setup_audio_sliders():
	var music_bus = AudioServer.get_bus_index("Music")
	var sfx_bus = AudioServer.get_bus_index("SFX")
	
	music_slider.min_value = 0
	music_slider.max_value = 100
	music_slider.step = 1
	if music_bus != -1:
		music_slider.value = db_to_linear(AudioServer.get_bus_volume_db(music_bus)) * 100
	music_slider.value_changed.connect(_on_music_changed)

	sfx_slider.min_value = 0
	sfx_slider.max_value = 100
	sfx_slider.step = 1
	if sfx_bus != -1:
		sfx_slider.value = db_to_linear(AudioServer.get_bus_volume_db(sfx_bus)) * 100
	sfx_slider.value_changed.connect(_on_sfx_changed)

func setup_layout():
	anchor_right = 1.0
	anchor_bottom = 1.0
	
	if bg:
		bg.anchor_right = 1.0
		bg.anchor_bottom = 1.0
		bg.color = Color(0.1, 0.08, 0.14, 1.0)
	
	if list:
		list.anchor_left = 0.3
		list.anchor_top = 0.05
		list.anchor_right = 0.7
		list.anchor_bottom = 0.95
		list.alignment = BoxContainer.ALIGNMENT_CENTER
		list.add_theme_constant_override("separation", 10)
	
	if title:
		title.text = "SETTINGS"
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		title.add_theme_font_size_override("font_size", 36)
	
	if fps_label: fps_label.text = "FPS Limit:"
	if quality_label: quality_label.text = "2D Quality:"
	if music_label: music_label.text = "Music Volume:"
	if sfx_label: sfx_label.text = "SFX Volume:"
	
	if fps_options: fps_options.custom_minimum_size = Vector2(0, 40)
	if quality_options: quality_options.custom_minimum_size = Vector2(0, 40)
	if music_slider: music_slider.custom_minimum_size = Vector2(0, 30)
	if sfx_slider: sfx_slider.custom_minimum_size = Vector2(0, 30)
	
	if back_btn:
		back_btn.text = "BACK"
		back_btn.custom_minimum_size = Vector2(0, 50)
		var btn_style = StyleBoxFlat.new()
		btn_style.bg_color = Color(0.3, 0.3, 0.35, 1.0)
		btn_style.corner_radius_top_left = 6
		btn_style.corner_radius_top_right = 6
		btn_style.corner_radius_bottom_left = 6
		btn_style.corner_radius_bottom_right = 6
		back_btn.add_theme_stylebox_override("normal", btn_style)

func _on_fps_changed(index: int):
	Engine.max_fps = fps_options.get_item_id(index)

func _on_quality_changed(index: int):
	match index:
		0:
			get_viewport().msaa_2d = Viewport.MSAA_DISABLED
		1:
			get_viewport().msaa_2d = Viewport.MSAA_2X
		2:
			get_viewport().msaa_2d = Viewport.MSAA_4X

func _on_music_changed(val: float):
	var bus_index = AudioServer.get_bus_index("Music")
	if bus_index != -1:
		if val <= 0:
			AudioServer.set_bus_mute(bus_index, true)
		else:
			AudioServer.set_bus_mute(bus_index, false)
			var linear_val = val / 100.0
			AudioServer.set_bus_volume_db(bus_index, linear_to_db(linear_val))

func _on_sfx_changed(val: float):
	var bus_index = AudioServer.get_bus_index("SFX")
	if bus_index != -1:
		if val <= 0:
			AudioServer.set_bus_mute(bus_index, true)
		else:
			AudioServer.set_bus_mute(bus_index, false)
			var linear_val = val / 100.0
			AudioServer.set_bus_volume_db(bus_index, linear_to_db(linear_val))

func _on_back():
	get_tree().change_scene_to_file(main_menu_path)
