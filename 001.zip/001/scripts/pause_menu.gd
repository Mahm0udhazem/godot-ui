extends CanvasLayer

@export var settings_scene: PackedScene
@export var main_menu_scene: PackedScene

@onready var overlay = $MenuOverlay

func _ready():
	process_mode = PROCESS_MODE_ALWAYS
	overlay.show()

func _input(event):
	if event.is_action_pressed("ui_cancel") and not event.is_echo():
		toggle_pause()

func toggle_pause():
	var new_state = !get_tree().paused
	get_tree().paused = new_state
	overlay.visible = new_state

func _on_resume_pressed():
	toggle_pause()

func _on_options_pressed():
	get_tree().paused = false
	NewScript.previous_scene = load("res://scenes/pause_menu.tscn")
	if settings_scene:
		get_tree().change_scene_to_packed(settings_scene)
func _on_main_menu_pressed():
	get_tree().paused = false
	if main_menu_scene:
		get_tree().change_scene_to_packed(main_menu_scene)
