@tool
extends CanvasLayer

@export var settings_scene_path: String = "res://SettingsMenu.tscn"
@export var main_menu_scene_path: String = "res://MainMenu.tscn"

@onready var overlay = $MenuOverlay
@onready var bg = $MenuOverlay/DarkBackground
@onready var list = $MenuOverlay/PauseList
@onready var resume_btn = $MenuOverlay/PauseList/ResumeButton
@onready var options_btn = $MenuOverlay/PauseList/OptionsButton
@onready var main_menu_btn = $MenuOverlay/PauseList/MainMenuButton

func _ready():
	setup_layout()
	if not Engine.is_editor_hint():
		overlay.hide()
		resume_btn.pressed.connect(_on_resume)
		options_btn.pressed.connect(_on_options)
		main_menu_btn.pressed.connect(_on_main_menu)

func setup_layout():
	if overlay:
		overlay.anchor_right = 1.0
		overlay.anchor_bottom = 1.0
	
	if bg:
		bg.anchor_right = 1.0
		bg.anchor_bottom = 1.0
		bg.color = Color(0.05, 0.05, 0.08, 0.95)
	
	if list:
		list.anchor_left = 0.35
		list.anchor_top = 0.25
		list.anchor_right = 0.65
		list.anchor_bottom = 0.75
		list.alignment = BoxContainer.ALIGNMENT_CENTER
		list.add_theme_constant_override("separation", 15)
	
	if resume_btn:
		style_button(resume_btn, "RESUME", Color(0.2, 0.55, 0.35, 1.0))
	if options_btn:
		style_button(options_btn, "OPTIONS", Color(0.25, 0.35, 0.6, 1.0))
	if main_menu_btn:
		style_button(main_menu_btn, "MAIN MENU", Color(0.55, 0.25, 0.25, 1.0))

func style_button(btn: Button, text_val: String, base_color: Color):
	btn.text = text_val
	btn.custom_minimum_size = Vector2(0, 50)
	
	var style_normal = StyleBoxFlat.new()
	style_normal.bg_color = base_color
	style_normal.corner_radius_top_left = 6
	style_normal.corner_radius_top_right = 6
	style_normal.corner_radius_bottom_left = 6
	style_normal.corner_radius_bottom_right = 6
	
	var style_hover = style_normal.duplicate()
	style_hover.bg_color = base_color.lightened(0.2)
	
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_hover)
	btn.add_theme_stylebox_override("pressed", style_normal)
	btn.add_theme_font_size_override("font_size", 18)

func _input(event):
	if Engine.is_editor_hint():
		return
	if event.is_action_pressed("ui_cancel"):
		var is_paused = !get_tree().paused
		get_tree().paused = is_paused
		overlay.visible = is_paused

func _on_resume():
	get_tree().paused = false
	overlay.hide()

func _on_options():
	get_tree().paused = false
	get_tree().change_scene_to_file(settings_scene_path)

func _on_main_menu():
	get_tree().paused = false
	get_tree().change_scene_to_file(main_menu_scene_path)
